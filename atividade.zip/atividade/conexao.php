<?php

$servidor = "localhost";
$usuario = "root";
$senha = "";
$conexao = new mysqli($servidor, $usuario,$senha, "Hackathon");
$conexao->set_charset("utf8");

?>