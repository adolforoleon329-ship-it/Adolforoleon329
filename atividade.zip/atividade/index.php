<?php
include('conexao.php');

$mensagem = '';
$nome = '';
$email = '';
$area = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'] ?? '';
    $email = $_POST['email'] ?? '';
    $area = $_POST['area'] ?? '';

    $sql = "INSERT INTO cadastro (nome, email, area) VALUES ('$nome', '$email', '$area')";

    if ($conexao->query($sql) === TRUE) {
        $mensagem = "Cadastro realizado com sucesso!";
    } else {
        $mensagem = "Erro ao cadastrar: " . $conexao->error;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $nome = $_GET['nome'] ?? '';
    $email = $_GET['email'] ?? '';
    $area = $_GET['area'] ?? '';

    if ($nome != '' || $email != '' || $area != '') {
        $sql = "SELECT * FROM cadastro WHERE 1=1";

        if ($nome != '') {
            $sql .= " AND nome LIKE '%$nome%'";
        }

        if ($email != '') {
            $sql .= " AND email LIKE '%$email%'";
        }

        if ($area != '') {
            $sql .= " AND area = '$area'";
        }

        $resultado = $conexao->query($sql);
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Hackathon SENAI</title>
</head>
<body>
    <div class="morango">
        <h2>Hackathon SENAI</h2><br>
    </div>

    <div class="form-container">
        <form method="POST">
            <h2>Preencha as informações</h2>
            <input type="text" name="nome" id="nome" placeholder="Digite seu nome"><br><br>
            <input type="email" name="email" id="email" placeholder="Digite seu email"><br><br>

            <label>Area de interesse: </label>
            <select name="area" id="area">
                <option value="">Selecione</option>
                <option value="automacao_industrial">Técnico em Automação Industrial</option>
                <option value="eletronica">Técnico em Eletrônica</option>
                <option value="seguranca_trabalho">Técnico em Segurança do Trabalho</option>
                <option value="manutencao_auto">Técnico em Manutenção Automotiva</option>
            </select><br><br>

            <input type="submit" value="enviar">
        </form>
    </div>

    <div class="form-container">
        <form method="GET">
            <h2>Consultar cadastro</h2>
            <input type="text" name="nome" placeholder="Nome para consultar"><br><br>
            <input type="email" name="email" placeholder="Email para consultar"><br><br>

            <label>Area de interesse: </label>
            <select name="area">
                <option value="">Selecione</option>
                <option value="automacao_industrial">Técnico em Automação Industrial</option>
                <option value="eletronica">Técnico em Eletrônica</option>
                <option value="seguranca_trabalho">Técnico em Segurança do Trabalho</option>
                <option value="manutencao_auto">Técnico em Manutenção Automotiva</option>
            </select><br><br>

            <input type="submit" value="consultar">
        </form>
    </div>

    <?php if (isset($mensagem)) : ?>
        <p><?php echo $mensagem; ?></p>
    <?php endif; ?>

    <?php if (isset($resultado) && $resultado->num_rows > 0) : ?>
        <h3>Resultados da consulta</h3>
        <ul>
            <?php while ($row = $resultado->fetch_assoc()) : ?>
                <li><?php echo $row['nome']; ?> - <?php echo $row['email']; ?> - <?php echo $row['area']; ?></li>
            <?php endwhile; ?>
        </ul>
    <?php elseif (isset($resultado)) : ?>
        <p>Nenhum resultado encontrado.</p>
    <?php endif; ?>
</body>
</html>